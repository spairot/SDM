﻿using System;
using System.IO.Ports;
using System.Threading;

namespace SerialDataMonitor
{

    public class SerialportControl
    {
    }

    public class DataStreamEventArgs : EventArgs
    {
        #region Defines
        public string _Datas;
        #endregion

        #region Constructors
        public DataStreamEventArgs(string data)
        {
            _Datas = data;
        }
        #endregion

        #region Properties
        public string Response
        {
            get { return _Datas; }
        }
        #endregion
    }
    public class SerialClient : IDisposable
    {
        #region Defines
        private string _port;
        private Int32 _baudRate;
        private Int16 _DataBits;
        private Parity _Parity;
        private StopBits _StopBits;
        private SerialPort _serialPort;
        private Thread serThread;
        #endregion

        #region Constructors
        public SerialClient(DataSetting L_setting)
        {
            _port     = L_setting.ComPortName;
            _baudRate = L_setting.Baudrate;
            _DataBits = L_setting.DataBits;
            _Parity   = L_setting.Parity;
            _StopBits = L_setting.StopBits;

            serThread = new Thread(new ThreadStart(SerialReceiving));
            serThread.Priority = ThreadPriority.Normal;
            serThread.Name = "SerialHandle" + serThread.ManagedThreadId;
            serThread.IsBackground = true;  /*Background : will be terminated when you close your application.*/
        }
        #endregion

        #region Custom Events
        public event EventHandler<DataStreamEventArgs> OnReceiving;
        #endregion

        #region Properties
        public string Port
        {
            get { return _port; }
        }
        public int BaudRate
        {
            get { return _baudRate; }
        }
        public string ConnectionString
        {
            get
            {
                return String.Format("[Serial] Port: {0} | Baudrate: {1}",
                    _serialPort.PortName, _serialPort.BaudRate.ToString());
            }
        }
        #endregion

        #region Methods
        #region Port Control
        public bool OpenConn()
        {
            try
            {
                if (_serialPort == null)
                    _serialPort = new SerialPort(_port, _baudRate, _Parity, _DataBits, _StopBits);

                if (!_serialPort.IsOpen)
                {
                    _serialPort.ReadTimeout = -1;
                    _serialPort.WriteTimeout = -1;

                    _serialPort.Open();

                    if (_serialPort.IsOpen)
                        serThread.Start(); /*Start The Communication Thread*/
                }
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }
        public bool OpenConn(string port, int baudRate)
        {
            _port = port;
            _baudRate = baudRate;

            return OpenConn();
        }
        public bool CloseConn()
        {
            if (_serialPort != null && _serialPort.IsOpen)
            {
                serThread.Abort();
                //serThread.Join();

                if (serThread.ThreadState == ThreadState.Aborted)
                    try { _serialPort.Close(); } catch { };
            }

            return true;
        }
        public bool ResetConn()
        {
            CloseConn();
            return OpenConn();
        }

        public void PauseConn()
        {
            if (0 != (serThread.ThreadState & (ThreadState.Suspended | ThreadState.SuspendRequested)))
            {
                //serThread.Resume();
            }
            else
            {
                //serThread.Suspend();
            }
        }

        public void ExitConn()
        {
            if ((serThread.ThreadState & ThreadState.Running) == ThreadState.Running)
                serThread.Abort();

            serThread = null;
        }

        #endregion
        #region Transmit/Receive
        public bool TransmitString(string packet)
        {
            if (_serialPort != null)
            {
                _serialPort.Write(packet + "\r\n");
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool TransmitByte(byte[] packet)
        {
            if (_serialPort != null)
            {
                _serialPort.Write(packet, 0, packet.Length);
                return true;
            }
            else
            {
                return false;
            }
        }

        public int Receive(byte[] bytes, int offset, int count)
        {
            int readBytes = 0;

            if (count > 0)
            {
                readBytes = _serialPort.Read(bytes, offset, count);
            }

            return readBytes;
        }
        #endregion
        #region IDisposable Methods
        public void Dispose()
        {
            CloseConn();

            if (_serialPort != null)
            {
                try { _serialPort.Dispose(); } catch { };
                _serialPort = null;
            }
        }
        #endregion
        #endregion

        #region Threading Loops
        private void SerialReceiving()
        {
            string InputData = String.Empty;
            while (true)
            {
                if (_serialPort != null)
                {
                    try
                    {
                        InputData = _serialPort.ReadExisting();  /*Read data from Serial port*/
                        if (InputData != string.Empty)
                        {
                            OnSerialReceiving(InputData);
                        }
                    }
                    catch (Exception)
                    {
                        return;
                    }
                }

            }
        }
        #endregion

        #region Custom Events Invoke Functions
        private void OnSerialReceiving(string res)
        {
            if (OnReceiving != null)
            {
                OnReceiving(this, new DataStreamEventArgs(res));
            }
        }
        #endregion
    }
}
