﻿namespace SerialDataMonitor.Forms
{
    partial class FrmSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSetting));
            this.groupBoxSerial = new System.Windows.Forms.GroupBox();
            this.btnRefreshComport = new System.Windows.Forms.Button();
            this.cmbSettingStopBit = new System.Windows.Forms.ComboBox();
            this.cmbSettingParity = new System.Windows.Forms.ComboBox();
            this.cmbSettingDataBits = new System.Windows.Forms.ComboBox();
            this.cmbSettingBaudrate = new System.Windows.Forms.ComboBox();
            this.cmbSettingComPort = new System.Windows.Forms.ComboBox();
            this.lblStopbit = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblParity = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblDatabit = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblBaudrate = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblComport = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnSettingCancel = new System.Windows.Forms.Button();
            this.btnSettingOK = new System.Windows.Forms.Button();
            this.groupBoxFont = new System.Windows.Forms.GroupBox();
            this.pnlRed = new System.Windows.Forms.Panel();
            this.txtTextColors1 = new System.Windows.Forms.TextBox();
            this.chkDispScroll = new Bunifu.Framework.UI.BunifuCheckbox();
            this.lblScroll = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnResetFontStyle = new System.Windows.Forms.Button();
            this.lblTextColor4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblTextColor3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblTextColor2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.cmbSettingFontColor = new System.Windows.Forms.ComboBox();
            this.lblTextColor1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblFontNumber = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlGreen = new System.Windows.Forms.Panel();
            this.txtTextColors2 = new System.Windows.Forms.TextBox();
            this.pnlBlue = new System.Windows.Forms.Panel();
            this.txtTextColors3 = new System.Windows.Forms.TextBox();
            this.pnlPeru = new System.Windows.Forms.Panel();
            this.txtTextColors4 = new System.Windows.Forms.TextBox();
            this.pnlDarkViolet = new System.Windows.Forms.Panel();
            this.txtTextColors5 = new System.Windows.Forms.TextBox();
            this.pnlGold = new System.Windows.Forms.Panel();
            this.txtTextColors6 = new System.Windows.Forms.TextBox();
            this.pnlDarkOrange = new System.Windows.Forms.Panel();
            this.txtTextColors7 = new System.Windows.Forms.TextBox();
            this.pnlTurquise = new System.Windows.Forms.Panel();
            this.txtTextColors8 = new System.Windows.Forms.TextBox();
            this.groupBoxSerial.SuspendLayout();
            this.groupBoxFont.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxSerial
            // 
            this.groupBoxSerial.Controls.Add(this.btnRefreshComport);
            this.groupBoxSerial.Controls.Add(this.cmbSettingStopBit);
            this.groupBoxSerial.Controls.Add(this.cmbSettingParity);
            this.groupBoxSerial.Controls.Add(this.cmbSettingDataBits);
            this.groupBoxSerial.Controls.Add(this.cmbSettingBaudrate);
            this.groupBoxSerial.Controls.Add(this.cmbSettingComPort);
            this.groupBoxSerial.Controls.Add(this.lblStopbit);
            this.groupBoxSerial.Controls.Add(this.lblParity);
            this.groupBoxSerial.Controls.Add(this.lblDatabit);
            this.groupBoxSerial.Controls.Add(this.lblBaudrate);
            this.groupBoxSerial.Controls.Add(this.lblComport);
            this.groupBoxSerial.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSerial.Location = new System.Drawing.Point(30, 12);
            this.groupBoxSerial.Name = "groupBoxSerial";
            this.groupBoxSerial.Size = new System.Drawing.Size(342, 265);
            this.groupBoxSerial.TabIndex = 0;
            this.groupBoxSerial.TabStop = false;
            this.groupBoxSerial.Text = "Serial port";
            // 
            // btnRefreshComport
            // 
            this.btnRefreshComport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefreshComport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefreshComport.FlatAppearance.BorderSize = 0;
            this.btnRefreshComport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefreshComport.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshComport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.btnRefreshComport.Image = ((System.Drawing.Image)(resources.GetObject("btnRefreshComport.Image")));
            this.btnRefreshComport.Location = new System.Drawing.Point(288, 50);
            this.btnRefreshComport.Name = "btnRefreshComport";
            this.btnRefreshComport.Size = new System.Drawing.Size(40, 30);
            this.btnRefreshComport.TabIndex = 4;
            this.btnRefreshComport.UseVisualStyleBackColor = true;
            this.btnRefreshComport.Click += new System.EventHandler(this.btnRefreshComport_Click);
            // 
            // cmbSettingStopBit
            // 
            this.cmbSettingStopBit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.cmbSettingStopBit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingStopBit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingStopBit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingStopBit.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingStopBit.FormattingEnabled = true;
            this.cmbSettingStopBit.Items.AddRange(new object[] {
            "One",
            "OnePointFive",
            "Two"});
            this.cmbSettingStopBit.Location = new System.Drawing.Point(125, 197);
            this.cmbSettingStopBit.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSettingStopBit.Name = "cmbSettingStopBit";
            this.cmbSettingStopBit.Size = new System.Drawing.Size(150, 28);
            this.cmbSettingStopBit.TabIndex = 5;
            // 
            // cmbSettingParity
            // 
            this.cmbSettingParity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.cmbSettingParity.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingParity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingParity.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingParity.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingParity.FormattingEnabled = true;
            this.cmbSettingParity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cmbSettingParity.Location = new System.Drawing.Point(125, 160);
            this.cmbSettingParity.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSettingParity.Name = "cmbSettingParity";
            this.cmbSettingParity.Size = new System.Drawing.Size(150, 28);
            this.cmbSettingParity.TabIndex = 4;
            // 
            // cmbSettingDataBits
            // 
            this.cmbSettingDataBits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.cmbSettingDataBits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingDataBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingDataBits.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingDataBits.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingDataBits.FormattingEnabled = true;
            this.cmbSettingDataBits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.cmbSettingDataBits.Location = new System.Drawing.Point(125, 123);
            this.cmbSettingDataBits.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSettingDataBits.Name = "cmbSettingDataBits";
            this.cmbSettingDataBits.Size = new System.Drawing.Size(150, 28);
            this.cmbSettingDataBits.TabIndex = 3;
            // 
            // cmbSettingBaudrate
            // 
            this.cmbSettingBaudrate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.cmbSettingBaudrate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingBaudrate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingBaudrate.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingBaudrate.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingBaudrate.FormattingEnabled = true;
            this.cmbSettingBaudrate.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.cmbSettingBaudrate.Location = new System.Drawing.Point(125, 86);
            this.cmbSettingBaudrate.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSettingBaudrate.Name = "cmbSettingBaudrate";
            this.cmbSettingBaudrate.Size = new System.Drawing.Size(150, 28);
            this.cmbSettingBaudrate.TabIndex = 2;
            // 
            // cmbSettingComPort
            // 
            this.cmbSettingComPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.cmbSettingComPort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingComPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingComPort.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingComPort.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingComPort.FormattingEnabled = true;
            this.cmbSettingComPort.Location = new System.Drawing.Point(125, 49);
            this.cmbSettingComPort.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSettingComPort.Name = "cmbSettingComPort";
            this.cmbSettingComPort.Size = new System.Drawing.Size(150, 28);
            this.cmbSettingComPort.TabIndex = 1;
            this.cmbSettingComPort.Text = "COM1";
            // 
            // lblStopbit
            // 
            this.lblStopbit.AutoSize = true;
            this.lblStopbit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStopbit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblStopbit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblStopbit.Location = new System.Drawing.Point(12, 199);
            this.lblStopbit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStopbit.Name = "lblStopbit";
            this.lblStopbit.Size = new System.Drawing.Size(92, 21);
            this.lblStopbit.TabIndex = 0;
            this.lblStopbit.Text = "Stop bits :";
            // 
            // lblParity
            // 
            this.lblParity.AutoSize = true;
            this.lblParity.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblParity.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblParity.Location = new System.Drawing.Point(12, 162);
            this.lblParity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblParity.Name = "lblParity";
            this.lblParity.Size = new System.Drawing.Size(65, 21);
            this.lblParity.TabIndex = 0;
            this.lblParity.Text = "Parity :";
            // 
            // lblDatabit
            // 
            this.lblDatabit.AutoSize = true;
            this.lblDatabit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblDatabit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDatabit.Location = new System.Drawing.Point(12, 125);
            this.lblDatabit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDatabit.Name = "lblDatabit";
            this.lblDatabit.Size = new System.Drawing.Size(98, 21);
            this.lblDatabit.TabIndex = 0;
            this.lblDatabit.Text = "Data bits :";
            // 
            // lblBaudrate
            // 
            this.lblBaudrate.AutoSize = true;
            this.lblBaudrate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaudrate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblBaudrate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBaudrate.Location = new System.Drawing.Point(12, 89);
            this.lblBaudrate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBaudrate.Name = "lblBaudrate";
            this.lblBaudrate.Size = new System.Drawing.Size(99, 21);
            this.lblBaudrate.TabIndex = 0;
            this.lblBaudrate.Text = "Baudrate :";
            // 
            // lblComport
            // 
            this.lblComport.AutoSize = true;
            this.lblComport.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblComport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblComport.Location = new System.Drawing.Point(12, 52);
            this.lblComport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblComport.Name = "lblComport";
            this.lblComport.Size = new System.Drawing.Size(100, 21);
            this.lblComport.TabIndex = 0;
            this.lblComport.Text = "Com port :";
            // 
            // btnSettingCancel
            // 
            this.btnSettingCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSettingCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingCancel.FlatAppearance.BorderSize = 0;
            this.btnSettingCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettingCancel.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingCancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.btnSettingCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingCancel.Image")));
            this.btnSettingCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingCancel.Location = new System.Drawing.Point(797, 454);
            this.btnSettingCancel.Name = "btnSettingCancel";
            this.btnSettingCancel.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSettingCancel.Size = new System.Drawing.Size(150, 50);
            this.btnSettingCancel.TabIndex = 1;
            this.btnSettingCancel.Text = "      Cancel";
            this.btnSettingCancel.UseVisualStyleBackColor = true;
            this.btnSettingCancel.Click += new System.EventHandler(this.btnSettingCancel_Click_1);
            // 
            // btnSettingOK
            // 
            this.btnSettingOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSettingOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingOK.FlatAppearance.BorderSize = 0;
            this.btnSettingOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettingOK.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingOK.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.btnSettingOK.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingOK.Image")));
            this.btnSettingOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingOK.Location = new System.Drawing.Point(957, 454);
            this.btnSettingOK.Name = "btnSettingOK";
            this.btnSettingOK.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSettingOK.Size = new System.Drawing.Size(140, 50);
            this.btnSettingOK.TabIndex = 2;
            this.btnSettingOK.Text = "      OK";
            this.btnSettingOK.UseVisualStyleBackColor = true;
            this.btnSettingOK.Click += new System.EventHandler(this.btnSettingOK_Click);
            // 
            // groupBoxFont
            // 
            this.groupBoxFont.Controls.Add(this.pnlTurquise);
            this.groupBoxFont.Controls.Add(this.pnlDarkOrange);
            this.groupBoxFont.Controls.Add(this.txtTextColors8);
            this.groupBoxFont.Controls.Add(this.txtTextColors7);
            this.groupBoxFont.Controls.Add(this.pnlGold);
            this.groupBoxFont.Controls.Add(this.txtTextColors6);
            this.groupBoxFont.Controls.Add(this.pnlDarkViolet);
            this.groupBoxFont.Controls.Add(this.txtTextColors5);
            this.groupBoxFont.Controls.Add(this.pnlPeru);
            this.groupBoxFont.Controls.Add(this.txtTextColors4);
            this.groupBoxFont.Controls.Add(this.pnlBlue);
            this.groupBoxFont.Controls.Add(this.txtTextColors3);
            this.groupBoxFont.Controls.Add(this.pnlGreen);
            this.groupBoxFont.Controls.Add(this.txtTextColors2);
            this.groupBoxFont.Controls.Add(this.pnlRed);
            this.groupBoxFont.Controls.Add(this.txtTextColors1);
            this.groupBoxFont.Controls.Add(this.chkDispScroll);
            this.groupBoxFont.Controls.Add(this.lblScroll);
            this.groupBoxFont.Controls.Add(this.btnResetFontStyle);
            this.groupBoxFont.Controls.Add(this.lblTextColor4);
            this.groupBoxFont.Controls.Add(this.lblTextColor3);
            this.groupBoxFont.Controls.Add(this.lblTextColor2);
            this.groupBoxFont.Controls.Add(this.cmbSettingFontColor);
            this.groupBoxFont.Controls.Add(this.lblTextColor1);
            this.groupBoxFont.Controls.Add(this.lblFontNumber);
            this.groupBoxFont.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxFont.Location = new System.Drawing.Point(378, 12);
            this.groupBoxFont.Name = "groupBoxFont";
            this.groupBoxFont.Size = new System.Drawing.Size(719, 265);
            this.groupBoxFont.TabIndex = 4;
            this.groupBoxFont.TabStop = false;
            this.groupBoxFont.Text = "Font Color";
            // 
            // pnlRed
            // 
            this.pnlRed.BackColor = System.Drawing.Color.Red;
            this.pnlRed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRed.ForeColor = System.Drawing.Color.Red;
            this.pnlRed.Location = new System.Drawing.Point(111, 117);
            this.pnlRed.Name = "pnlRed";
            this.pnlRed.Size = new System.Drawing.Size(280, 1);
            this.pnlRed.TabIndex = 5;
            // 
            // txtTextColors1
            // 
            this.txtTextColors1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors1.ForeColor = System.Drawing.Color.Red;
            this.txtTextColors1.Location = new System.Drawing.Point(111, 89);
            this.txtTextColors1.MaxLength = 0;
            this.txtTextColors1.Multiline = true;
            this.txtTextColors1.Name = "txtTextColors1";
            this.txtTextColors1.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors1.TabIndex = 5;
            // 
            // chkDispScroll
            // 
            this.chkDispScroll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkDispScroll.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkDispScroll.Checked = false;
            this.chkDispScroll.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.chkDispScroll.ForeColor = System.Drawing.Color.White;
            this.chkDispScroll.Location = new System.Drawing.Point(553, 56);
            this.chkDispScroll.Margin = new System.Windows.Forms.Padding(19, 16, 19, 16);
            this.chkDispScroll.Name = "chkDispScroll";
            this.chkDispScroll.Size = new System.Drawing.Size(20, 20);
            this.chkDispScroll.TabIndex = 36;
            // 
            // lblScroll
            // 
            this.lblScroll.AutoSize = true;
            this.lblScroll.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.lblScroll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblScroll.Location = new System.Drawing.Point(407, 56);
            this.lblScroll.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblScroll.Name = "lblScroll";
            this.lblScroll.Size = new System.Drawing.Size(135, 21);
            this.lblScroll.TabIndex = 37;
            this.lblScroll.Text = "Freeze display :";
            // 
            // btnResetFontStyle
            // 
            this.btnResetFontStyle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnResetFontStyle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetFontStyle.FlatAppearance.BorderSize = 0;
            this.btnResetFontStyle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResetFontStyle.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetFontStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.btnResetFontStyle.Image = ((System.Drawing.Image)(resources.GetObject("btnResetFontStyle.Image")));
            this.btnResetFontStyle.Location = new System.Drawing.Point(282, 50);
            this.btnResetFontStyle.Name = "btnResetFontStyle";
            this.btnResetFontStyle.Size = new System.Drawing.Size(40, 30);
            this.btnResetFontStyle.TabIndex = 9;
            this.btnResetFontStyle.UseVisualStyleBackColor = true;
            this.btnResetFontStyle.Click += new System.EventHandler(this.btnResetFontStyle_Click);
            // 
            // lblTextColor4
            // 
            this.lblTextColor4.AutoSize = true;
            this.lblTextColor4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextColor4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblTextColor4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTextColor4.Location = new System.Drawing.Point(13, 225);
            this.lblTextColor4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTextColor4.Name = "lblTextColor4";
            this.lblTextColor4.Size = new System.Drawing.Size(54, 21);
            this.lblTextColor4.TabIndex = 14;
            this.lblTextColor4.Text = "Text :";
            // 
            // lblTextColor3
            // 
            this.lblTextColor3.AutoSize = true;
            this.lblTextColor3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextColor3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblTextColor3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTextColor3.Location = new System.Drawing.Point(13, 181);
            this.lblTextColor3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTextColor3.Name = "lblTextColor3";
            this.lblTextColor3.Size = new System.Drawing.Size(54, 21);
            this.lblTextColor3.TabIndex = 13;
            this.lblTextColor3.Text = "Text :";
            // 
            // lblTextColor2
            // 
            this.lblTextColor2.AutoSize = true;
            this.lblTextColor2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextColor2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblTextColor2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTextColor2.Location = new System.Drawing.Point(13, 137);
            this.lblTextColor2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTextColor2.Name = "lblTextColor2";
            this.lblTextColor2.Size = new System.Drawing.Size(54, 21);
            this.lblTextColor2.TabIndex = 12;
            this.lblTextColor2.Text = "Text :";
            // 
            // cmbSettingFontColor
            // 
            this.cmbSettingFontColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.cmbSettingFontColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingFontColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingFontColor.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingFontColor.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingFontColor.FormattingEnabled = true;
            this.cmbSettingFontColor.Items.AddRange(new object[] {
            "Magenta",
            "Red",
            "Green",
            "Blue",
            "Black"});
            this.cmbSettingFontColor.Location = new System.Drawing.Point(111, 49);
            this.cmbSettingFontColor.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSettingFontColor.Name = "cmbSettingFontColor";
            this.cmbSettingFontColor.Size = new System.Drawing.Size(150, 28);
            this.cmbSettingFontColor.TabIndex = 0;
            this.cmbSettingFontColor.Text = "Margenta";
            this.cmbSettingFontColor.SelectedIndexChanged += new System.EventHandler(this.cmbSettingFontColor_SelectedIndexChanged);
            // 
            // lblTextColor1
            // 
            this.lblTextColor1.AutoSize = true;
            this.lblTextColor1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTextColor1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblTextColor1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTextColor1.Location = new System.Drawing.Point(13, 93);
            this.lblTextColor1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTextColor1.Name = "lblTextColor1";
            this.lblTextColor1.Size = new System.Drawing.Size(54, 21);
            this.lblTextColor1.TabIndex = 11;
            this.lblTextColor1.Text = "Text :";
            // 
            // lblFontNumber
            // 
            this.lblFontNumber.AutoSize = true;
            this.lblFontNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFontNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.lblFontNumber.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblFontNumber.Location = new System.Drawing.Point(12, 52);
            this.lblFontNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFontNumber.Name = "lblFontNumber";
            this.lblFontNumber.Size = new System.Drawing.Size(86, 21);
            this.lblFontNumber.TabIndex = 10;
            this.lblFontNumber.Text = "Number :";
            // 
            // pnlGreen
            // 
            this.pnlGreen.BackColor = System.Drawing.Color.Green;
            this.pnlGreen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlGreen.ForeColor = System.Drawing.Color.Green;
            this.pnlGreen.Location = new System.Drawing.Point(111, 161);
            this.pnlGreen.Name = "pnlGreen";
            this.pnlGreen.Size = new System.Drawing.Size(280, 1);
            this.pnlGreen.TabIndex = 38;
            // 
            // txtTextColors2
            // 
            this.txtTextColors2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors2.ForeColor = System.Drawing.Color.Green;
            this.txtTextColors2.Location = new System.Drawing.Point(111, 133);
            this.txtTextColors2.MaxLength = 0;
            this.txtTextColors2.Multiline = true;
            this.txtTextColors2.Name = "txtTextColors2";
            this.txtTextColors2.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors2.TabIndex = 39;
            // 
            // pnlBlue
            // 
            this.pnlBlue.BackColor = System.Drawing.Color.Blue;
            this.pnlBlue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBlue.ForeColor = System.Drawing.Color.Blue;
            this.pnlBlue.Location = new System.Drawing.Point(111, 206);
            this.pnlBlue.Name = "pnlBlue";
            this.pnlBlue.Size = new System.Drawing.Size(280, 1);
            this.pnlBlue.TabIndex = 6;
            // 
            // txtTextColors3
            // 
            this.txtTextColors3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors3.ForeColor = System.Drawing.Color.Blue;
            this.txtTextColors3.Location = new System.Drawing.Point(111, 178);
            this.txtTextColors3.MaxLength = 0;
            this.txtTextColors3.Multiline = true;
            this.txtTextColors3.Name = "txtTextColors3";
            this.txtTextColors3.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors3.TabIndex = 7;
            // 
            // pnlPeru
            // 
            this.pnlPeru.BackColor = System.Drawing.Color.Peru;
            this.pnlPeru.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlPeru.ForeColor = System.Drawing.Color.Peru;
            this.pnlPeru.Location = new System.Drawing.Point(111, 250);
            this.pnlPeru.Name = "pnlPeru";
            this.pnlPeru.Size = new System.Drawing.Size(280, 1);
            this.pnlPeru.TabIndex = 6;
            // 
            // txtTextColors4
            // 
            this.txtTextColors4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors4.ForeColor = System.Drawing.Color.Peru;
            this.txtTextColors4.Location = new System.Drawing.Point(111, 222);
            this.txtTextColors4.MaxLength = 0;
            this.txtTextColors4.Multiline = true;
            this.txtTextColors4.Name = "txtTextColors4";
            this.txtTextColors4.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors4.TabIndex = 7;
            // 
            // pnlDarkViolet
            // 
            this.pnlDarkViolet.BackColor = System.Drawing.Color.DarkViolet;
            this.pnlDarkViolet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlDarkViolet.ForeColor = System.Drawing.Color.DarkViolet;
            this.pnlDarkViolet.Location = new System.Drawing.Point(410, 117);
            this.pnlDarkViolet.Name = "pnlDarkViolet";
            this.pnlDarkViolet.Size = new System.Drawing.Size(280, 1);
            this.pnlDarkViolet.TabIndex = 6;
            // 
            // txtTextColors5
            // 
            this.txtTextColors5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors5.ForeColor = System.Drawing.Color.DarkViolet;
            this.txtTextColors5.Location = new System.Drawing.Point(410, 89);
            this.txtTextColors5.MaxLength = 0;
            this.txtTextColors5.Multiline = true;
            this.txtTextColors5.Name = "txtTextColors5";
            this.txtTextColors5.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors5.TabIndex = 7;
            // 
            // pnlGold
            // 
            this.pnlGold.BackColor = System.Drawing.Color.Magenta;
            this.pnlGold.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlGold.ForeColor = System.Drawing.Color.Magenta;
            this.pnlGold.Location = new System.Drawing.Point(411, 161);
            this.pnlGold.Name = "pnlGold";
            this.pnlGold.Size = new System.Drawing.Size(280, 1);
            this.pnlGold.TabIndex = 40;
            // 
            // txtTextColors6
            // 
            this.txtTextColors6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors6.ForeColor = System.Drawing.Color.Magenta;
            this.txtTextColors6.Location = new System.Drawing.Point(411, 133);
            this.txtTextColors6.MaxLength = 0;
            this.txtTextColors6.Multiline = true;
            this.txtTextColors6.Name = "txtTextColors6";
            this.txtTextColors6.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors6.TabIndex = 41;
            // 
            // pnlDarkOrange
            // 
            this.pnlDarkOrange.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlDarkOrange.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlDarkOrange.ForeColor = System.Drawing.Color.DarkOrange;
            this.pnlDarkOrange.Location = new System.Drawing.Point(411, 206);
            this.pnlDarkOrange.Name = "pnlDarkOrange";
            this.pnlDarkOrange.Size = new System.Drawing.Size(280, 1);
            this.pnlDarkOrange.TabIndex = 42;
            // 
            // txtTextColors7
            // 
            this.txtTextColors7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors7.ForeColor = System.Drawing.Color.DarkOrange;
            this.txtTextColors7.Location = new System.Drawing.Point(411, 178);
            this.txtTextColors7.MaxLength = 0;
            this.txtTextColors7.Multiline = true;
            this.txtTextColors7.Name = "txtTextColors7";
            this.txtTextColors7.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors7.TabIndex = 43;
            // 
            // pnlTurquise
            // 
            this.pnlTurquise.BackColor = System.Drawing.Color.Turquoise;
            this.pnlTurquise.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlTurquise.ForeColor = System.Drawing.Color.Turquoise;
            this.pnlTurquise.Location = new System.Drawing.Point(410, 250);
            this.pnlTurquise.Name = "pnlTurquise";
            this.pnlTurquise.Size = new System.Drawing.Size(280, 1);
            this.pnlTurquise.TabIndex = 6;
            // 
            // txtTextColors8
            // 
            this.txtTextColors8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTextColors8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTextColors8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTextColors8.ForeColor = System.Drawing.Color.Turquoise;
            this.txtTextColors8.Location = new System.Drawing.Point(410, 222);
            this.txtTextColors8.MaxLength = 0;
            this.txtTextColors8.Multiline = true;
            this.txtTextColors8.Name = "txtTextColors8";
            this.txtTextColors8.Size = new System.Drawing.Size(280, 25);
            this.txtTextColors8.TabIndex = 7;
            // 
            // FrmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1122, 530);
            this.Controls.Add(this.groupBoxFont);
            this.Controls.Add(this.btnSettingOK);
            this.Controls.Add(this.btnSettingCancel);
            this.Controls.Add(this.groupBoxSerial);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSetting";
            this.Text = "Setting";
            this.Load += new System.EventHandler(this.FrmSetting_Load);
            this.groupBoxSerial.ResumeLayout(false);
            this.groupBoxSerial.PerformLayout();
            this.groupBoxFont.ResumeLayout(false);
            this.groupBoxFont.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxSerial;
        private System.Windows.Forms.ComboBox cmbSettingStopBit;
        private System.Windows.Forms.ComboBox cmbSettingParity;
        private System.Windows.Forms.ComboBox cmbSettingDataBits;
        private System.Windows.Forms.ComboBox cmbSettingBaudrate;
        private System.Windows.Forms.ComboBox cmbSettingComPort;
        private Bunifu.Framework.UI.BunifuCustomLabel lblStopbit;
        private Bunifu.Framework.UI.BunifuCustomLabel lblParity;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDatabit;
        private Bunifu.Framework.UI.BunifuCustomLabel lblBaudrate;
        private Bunifu.Framework.UI.BunifuCustomLabel lblComport;
        private System.Windows.Forms.Button btnSettingCancel;
        private System.Windows.Forms.Button btnSettingOK;
        private System.Windows.Forms.Button btnRefreshComport;
        private System.Windows.Forms.GroupBox groupBoxFont;
        private System.Windows.Forms.ComboBox cmbSettingFontColor;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTextColor1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblFontNumber;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTextColor4;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTextColor3;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTextColor2;
        private System.Windows.Forms.Button btnResetFontStyle;
        private Bunifu.Framework.UI.BunifuCustomLabel lblScroll;
        private Bunifu.Framework.UI.BunifuCheckbox chkDispScroll;
        private System.Windows.Forms.TextBox txtTextColors1;
        private System.Windows.Forms.Panel pnlRed;
        private System.Windows.Forms.Panel pnlBlue;
        private System.Windows.Forms.TextBox txtTextColors3;
        private System.Windows.Forms.Panel pnlGreen;
        private System.Windows.Forms.TextBox txtTextColors2;
        private System.Windows.Forms.Panel pnlPeru;
        private System.Windows.Forms.TextBox txtTextColors4;
        private System.Windows.Forms.Panel pnlDarkViolet;
        private System.Windows.Forms.TextBox txtTextColors5;
        private System.Windows.Forms.Panel pnlGold;
        private System.Windows.Forms.TextBox txtTextColors6;
        private System.Windows.Forms.Panel pnlTurquise;
        private System.Windows.Forms.Panel pnlDarkOrange;
        private System.Windows.Forms.TextBox txtTextColors8;
        private System.Windows.Forms.TextBox txtTextColors7;
    }
}